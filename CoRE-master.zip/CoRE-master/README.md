# CoRE
CoRE - Community's own Rule Engine

[Description coming soon]
